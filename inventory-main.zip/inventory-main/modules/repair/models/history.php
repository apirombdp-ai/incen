<?php
/**
 * @filesource modules/repair/models/history.php
 *
 * @copyright 2016 Goragod.com
 * @license https://www.kotchasan.com/license/
 *
 * @see https://www.kotchasan.com/
 */

namespace Repair\History;

use Kotchasan\Database\Sql;

/**
 * module=repair-history
 *
 * @author Goragod Wiriya <admin@goragod.com>
 *
 * @since 1.0
 */
class Model extends \Kotchasan\Model
{
    /**
     * Query ข้อมูลสำหรับส่งให้กับ DataTable
     *
     * @param array $params
     *
     * @return \Kotchasan\Database\QueryBuilder
     */
    public static function toDataTable($params)
    {
        $where = [
            ['R.customer_id', $params['customer_id']]
        ];
        if ($params['status'] > -1) {
            $where[] = ['S.status', $params['status']];
        }
        $q1 = static::createQuery()
            ->select('repair_id', Sql::MAX('id', 'max_id'))
            ->from('repair_status')
            ->groupBy('repair_id');
        return static::createQuery()
            ->select('R.id', 'R.job_id', 'V.topic', 'R.create_date', 'S.operator_id', 'S.status', 'S.comment')
            ->from('repair R')
            ->join([$q1, 'T'], 'LEFT', ['T.repair_id', 'R.id'])
            ->join('repair_status S', 'LEFT', ['S.id', 'T.max_id'])
            ->join('inventory_items I', 'LEFT', ['I.product_no', 'R.product_no'])
            ->join('inventory V', 'LEFT', ['V.id', 'I.inventory_id'])
            ->where($where);
    }
}
