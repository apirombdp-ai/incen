<?php
echo '<h2>ติดตั้งเรียบร้อยแล้ว</h2>';
echo '<p>คุณได้ทำการติดตั้ง Kotchasan เป็นที่เรียบร้อยแล้ว</p>';
echo '<p class=warning>เพื่อความปลอดภัย กรุณาลบไดเร็คทอรี่ <em>install/</em> ออกก่อนดำเนินการต่อ</p>';
echo '<p><a href="../index.php?module=system" class="button large admin">เข้าระบบ</a></p>';
